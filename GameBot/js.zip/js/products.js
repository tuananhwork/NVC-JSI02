const products = [
    {
        name: "product 1 pants",
        image: "Image here",
        desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, consequatur illum quibusdam beatae doloribus quo voluptatum quam voluptatibus nam modi nulla, enim eaque nisi tempora impedit, amet placeat pariatur soluta!",
        status: "New",
        category: "Type:...",
        price: 20000,
    },
    {
        name: "product 2 pants",
        image: "Image here",
        desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, consequatur illum quibusdam beatae doloribus quo voluptatum quam voluptatibus nam modi nulla, enim eaque nisi tempora impedit, amet placeat pariatur soluta!",
        status: "New",
        category: "Type:...",
        price: 20000,
    },
    {
        name: "product 3 pants",
        image: "Image here",
        desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, consequatur illum quibusdam beatae doloribus quo voluptatum quam voluptatibus nam modi nulla, enim eaque nisi tempora impedit, amet placeat pariatur soluta!",
        status: "New",
        category: "Type:...",
        price: 20000,
    },
    
]